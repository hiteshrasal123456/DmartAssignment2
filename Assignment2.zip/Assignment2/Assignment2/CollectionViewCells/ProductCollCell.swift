//
//  ProductCollCell.swift
//  Assignment2
//
//  Created by Hitesh Rasal on 21/09/21.
//

import UIKit
import SDWebImage

class ProductCollCell: UICollectionViewCell {

    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var imgProduct: UIImageView!
    
    var productName: String? {
        didSet {
            self.lblName.text = productName ?? ""
        }
    }
    var productImg: String? {
        didSet {
            if let productImg = productImg {
                imgProduct.sd_setImage(with: URL(string: productImg), placeholderImage: UIImage(named: "placeholder.png"))

            }
        }
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}

