//
//  ProductListCell.swift
//  Assignment2
//
//  Created by Hitesh Rasal on 21/09/21.
//

import UIKit
import SDWebImage
class ProductListCell: UITableViewCell {

    @IBOutlet weak var productImg: UIImageView!
    
    @IBOutlet weak var lblGm: UILabel!
    
    @IBOutlet weak var btnAddCart: UIButton!
    @IBOutlet weak var lblSave: UILabel!
    @IBOutlet weak var lblDmartPrice: UILabel!
    @IBOutlet weak var lblMrp: UILabel!
    @IBOutlet weak var lblName: UILabel!
    var product: ProductList? {
        didSet {
            if let img = product!.img {
                    productImg.sd_setImage(with: URL(string: img), placeholderImage: UIImage(named: "placeholder.png"))

            }

            self.lblMrp.text = "MRP ₹" + (product?.mrp ?? "")
            self.lblDmartPrice.text = "DMart ₹" + (product?.dmart ?? "")
            self.lblSave.text = "Save ₹" + (product?.save ?? "")
            self.lblGm.text = product?.gm ?? ""
            self.lblName.text = product?.productName ?? ""
        }
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        btnAddCart.layer.cornerRadius = 4
        lblGm.layer.borderWidth = 1
        lblGm.layer.borderColor = UIColor.green.cgColor
        lblGm.layer.cornerRadius = 4
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
}
