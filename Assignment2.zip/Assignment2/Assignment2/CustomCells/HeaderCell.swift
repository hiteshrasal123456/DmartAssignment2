//
//  HeaderCell.swift
//  Assignment2
//
//  Created by Hitesh Rasal on 21/09/21.
//

import UIKit

class HeaderCell: UITableViewHeaderFooterView {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
}
