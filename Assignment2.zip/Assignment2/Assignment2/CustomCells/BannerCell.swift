//
//  BannerCell.swift
//  Assignment2
//
//  Created by Hitesh Rasal on 21/09/21.
//

import UIKit

class BannerCell: UITableViewCell {

    @IBOutlet weak var imgVw: UIImageView!
    
    
    var imgName: String? {
        didSet {
            if imgName?.count ?? 0 > 0 {
                self.imgVw.image = UIImage(named: imgName!)
            }
        }
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
