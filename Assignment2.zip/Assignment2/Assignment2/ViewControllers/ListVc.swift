//
//  ListVc.swift
//  Assignment2
//
//  Created by Hitesh Rasal on 21/09/21.
//

import UIKit

class ListVc: UIViewController {

    @IBOutlet weak var tblVw: UITableView!
    var vwModelObj = ListVM()
    override func viewDidLoad() {
        super.viewDidLoad()
        configListUi()
    }
    
    func configListUi() {
        tblVw.register(UINib(nibName: "HeaderCell", bundle: nil), forHeaderFooterViewReuseIdentifier: CellIdentifier.headerCell.rawValue)
        tblVw.register(UINib(nibName: "BannerCell", bundle: nil), forCellReuseIdentifier: CellIdentifier.bannerCell.rawValue)
        tblVw.register(UINib(nibName: "ProductListCell", bundle: nil), forCellReuseIdentifier: CellIdentifier.productCell.rawValue)
        tblVw.register(UINib(nibName: "GridListCell", bundle: nil), forCellReuseIdentifier: CellIdentifier.gridCell.rawValue)
        tblVw.delegate = self
        tblVw.tableFooterView = UIView()
        DispatchQueue.main.async {
            if (self.vwModelObj.fetchDataFromJsonFile()) {
                self.tblVw.reloadData()
            }
        }
    }
    
}
//MARK: UITABLEVIEW DELEGATE METHOD
extension ListVc : UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return vwModelObj.cellTypeArray.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let cellType = vwModelObj.cellTypeArray[section]
        switch cellType {
        case ListCellType.bannerCell.rawValue:
            return vwModelObj.bannerType?.bannerlist?.count ?? 0
        case ListCellType.productCell.rawValue:
            return vwModelObj.productType?.productlist?.count ?? 0
        case ListCellType.gridCell.rawValue:
            return 1
        default:
            return 0
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellType = vwModelObj.cellTypeArray[indexPath.section]
        if cellType == ListCellType.bannerCell.rawValue {
            let cell = tableView.dequeueReusableCell(withIdentifier: CellIdentifier.bannerCell.rawValue) as! BannerCell
            cell.imgName = vwModelObj.bannerType?.bannerlist?[indexPath.row].imgName ?? ""
            return cell
        } else if cellType == ListCellType.gridCell.rawValue {
            let cell = tableView.dequeueReusableCell(withIdentifier: CellIdentifier.gridCell.rawValue) as! GridListCell
            cell.gridList = vwModelObj.gridType?.gridlist
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: CellIdentifier.productCell.rawValue) as! ProductListCell
            cell.product = vwModelObj.productType?.productlist?[indexPath.row]
            return cell
        }
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let cellType = vwModelObj.cellTypeArray[indexPath.section]
        switch cellType {
        case ListCellType.bannerCell.rawValue:
            return 80
        case ListCellType.productCell.rawValue:
            return 200
        case ListCellType.gridCell.rawValue:
            return  vwModelObj.calCollectionViewHeight()
        default:
            return 0
        }
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return .leastNormalMagnitude
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let cell = tableView.dequeueReusableHeaderFooterView(withIdentifier: CellIdentifier.headerCell.rawValue) as! HeaderCell
        return cell
    }
}
