//
//  ListVM.swift
//  Assignment2
//
//  Created by Hitesh Rasal on 21/09/21.
//

import UIKit
enum ListCellType: String {
    case bannerCell = "Banner"
    case productCell = "Product"
    case gridCell    =  "Grid"
}
class ListVM {
    var cellTypeArray = [String]()
    var productType: ProductType?
    var bannerType: BannerType?
    var gridType: GridType?
   
    func fetchDataFromJsonFile() -> Bool {
       var isReload = false
        if let path = Bundle.main.path(forResource: "MenuDataList", ofType: "json") {
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                if  let respDict = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String:Any] {
                    let filterData = try JSONSerialization.data(withJSONObject: respDict["data"] as Any, options: [])
                    let respModel = try JSONDecoder().decode([MenuListModel].self, from: filterData)
                  for respObj in respModel {
                    if let celltype = respObj.banner?.cellType {
                            self.cellTypeArray.append(celltype)
                            self.bannerType = respObj.banner
                        }
                        if let celltype = respObj.product?.cellType {
                            self.cellTypeArray.append(celltype)
                            self.productType = respObj.product
                        }
                        if let celltype = respObj.grid?.cellType {
                            self.cellTypeArray.append(celltype)
                            self.gridType = respObj.grid
                        }
                    }

                    isReload = true
                } else {
                    isReload = false
                }
              } catch let error {
                print("error while reading json from file is \(error)")
            }
        }
        return isReload
    }
    
    func calCollectionViewHeight() -> CGFloat {
        if let gridType = self.gridType {
            if gridType.gridlist?.count ?? 0 > 0 {
                let rowCount = gridType.gridlist!.count / 3
                return CGFloat(rowCount * 170)
            } else {
                return 0
            }
        }
        return 0
    }
}
