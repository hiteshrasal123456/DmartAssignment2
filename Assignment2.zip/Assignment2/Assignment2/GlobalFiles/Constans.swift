//
//  Constans.swift
//  Assignment2
//
//  Created by Hitesh Rasal on 21/09/21.
//

import UIKit
import Foundation



enum CellIdentifier: String {
    case bannerCell  = "BannerCellIdef"
    case productCell = "ProductListCellIdef"
    case gridCell    =  "GridListCellIdef"
    case headerCell  = "HeaderCellIdef"
}
enum CollectionCellIdentifier: String {
    case productCollCell  = "ProductCollCellIdef"
    
}

