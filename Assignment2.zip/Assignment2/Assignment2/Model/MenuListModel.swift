//
//  MenuListModel.swift
//  Assignment2
//
//  Created by Hitesh Rasal on 21/09/21.
//

import UIKit

struct MenuListModel:Codable {
    var product:ProductType?
    var banner:BannerType?
    var grid:GridType?
    
    enum CodingKeys: String, CodingKey {
        case product = "Product"
        case banner = "Banner"
        case grid = "Grid"
    }
}

struct ProductType: Codable {
    var cellType: String?
    var productlist: [ProductList]?
    
    enum CodingKeys: String, CodingKey {
        case cellType = "CellType"
        case productlist = "ProductList"
    }
}
struct ProductList: Codable {
    var productName: String?
    var mrp: String?
    var dmart: String?
    var save: String?
    var img: String?
    var gm: String?
    enum CodingKeys: String, CodingKey {
        case productName = "ProductName"
        case mrp = "Mrp"
        case dmart = "Dmart"
        case save = "Save"
        case img = "img"
        case gm = "Gm"
    }
}
struct BannerType: Codable {
    var cellType: String?
    var bannerlist: [BannerList]?
    enum CodingKeys: String, CodingKey {
        case cellType = "CellType"
        case bannerlist = "BannerList"
    }
}
struct BannerList: Codable {
    var productName: String?
    var imgName:String?
    enum CodingKeys: String, CodingKey {
        case productName = "ProductName"
        case imgName = "img"
    }
}
struct GridType: Codable {
    var cellType: String?
    var gridlist: [GridList]?
    enum CodingKeys: String, CodingKey {
        case cellType = "CellType"
        case gridlist = "GridList"
    }
}
struct GridList: Codable {
    var productName: String?
    var img: String?
    enum CodingKeys: String, CodingKey {
        case productName = "ProductName"
        case img = "img"
    }
}
